<!-- jQuery (required for DataTables plugin) -->
<script src="{{asset('assets')}}/js/lib/jquery.min.js"></script>

<!-- Page JS Plugins -->
<script src="{{asset('assets/js/plugins/datatables/jquery.dataTables.min.js')}}"></script>

    <script src="{{asset('assets/js/dashmix.app.min.js')}}"></script>

    <!-- Page JS Plugins -->

    <!-- Page JS Code -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.min.js"></script>
    @yield('scripts')
