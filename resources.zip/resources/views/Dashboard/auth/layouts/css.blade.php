<link rel="shortcut icon" href="{{asset('assets')}}/media/favicons/favicon.png">
<link rel="icon" type="image/png" sizes="192x192" href="{{asset('assets')}}/media/favicons/favicon-192x192.png">
<link rel="apple-touch-icon" sizes="180x180" href="{{asset('assets')}}/media/favicons/apple-touch-icon-180x180.png">
<link rel="stylesheet" id="css-main" href="{{asset('assets')}}/css/dashmix.min.css">
@yield('css')

