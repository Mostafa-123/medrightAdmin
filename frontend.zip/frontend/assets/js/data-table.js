
// data table

new DataTable("#example")
  $('.dataTables_wrapper input[type="search"]').attr("placeholder", "Search ");
